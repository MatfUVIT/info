$(document).ready(function() {
    $("#form1").submit(function()
    {
        let productId = $("#productId1").val();

        if (productId === "")
        {
            $.ajax("http://localhost:3000/products", {
                method: "GET",
                success: function(data) {
                    if(data.hasOwnProperty("poruka")) {
                        $("#rezultat1").text(data.poruka).css({color: "green"});
                    }
                },
                error: function() {
                    $("#rezultat1").text("Greska pri dohvatanju proizvoda!").css({color: "red"});
                }
            });
        }
        else
        {
            $.ajax(`http://localhost:3000/products/${productId}`, {
                method: "GET",
                success: function(data) {
                    if(data.hasOwnProperty("poruka")) {
                        $("#rezultat1").text(data.poruka).css({color: "green"});
                    }
                },
                error: function() {
                    $("#rezultat1").text("Greska pri dohvatanju proizvoda!").css({color: "red"});
                }
            });
        }

        $("#rezultat1").text("");

        return false;
    });

    $("#form2").submit(function()
    {
        let name = $("#name").val();
        let price = Number.parseFloat($("#price").val());

        if (name === "")
        {
            $("#rezultat2").text("Niste prosledili naziv proizvoda").css({color: "red"});
            return false;
        }

        if (Number.isNaN(price))
        {
            $("#rezultat2").text("Niste prosledili ispravnu cenu proizvoda").css({color: "red"});
            return false;
        }

        $.ajax("http://localhost:3000/products", {
            method: "POST",
            data: JSON.stringify({
                name, price
            }),
            contentType: 'application/json',
            success: function(data) {
                if(data.hasOwnProperty("kreiraniProizvod")) {
                    $("#rezultat2")
                        .text(`Kreirali ste proizvod:
                        ${JSON.stringify(data.kreiraniProizvod)}`)
                        .css({color: "green"});
                }
            },
            error: function() {
                $("#rezultat2").text("Greska pri postavljanju proizvoda!").css({color: "red"});
            }
        });

        return false;
    });

    $("#form3").submit(function()
    {
        let productId = $("#productId3").val();

        if (productId === "")
        {
            $("#rezultat3").text("Niste prosledili identifikator proizvoda").css({color: "red"});
            return false;
        }
        
        $.ajax(`http://localhost:3000/products/${productId}`, {
            method: "PATCH",
            success: function(data) {
                if(data.hasOwnProperty("poruka")) {
                    $("#rezultat3").text(data.poruka).css({color: "green"});
                }
            },
            error: function() {
                $("#rezultat3").text("Greska pri menjanju proizvoda!").css({color: "red"});
            }
        });

        $("#rezultat3").text("");
        return false;
    });

    $("#form4").submit(function()
    {
        let productId = $("#productId4").val();

        if (productId === "")
        {
            $("#rezultat4").text("Niste prosledili identifikator proizvoda").css({color: "red"});
            return false;
        }
        
        $.ajax(`http://localhost:3000/products/${productId}`, {
            method: "DELETE",
            success: function(data) {
                if(data.hasOwnProperty("poruka")) {
                    $("#rezultat4").text(data.poruka).css({color: "green"});
                }
            },
            error: function() {
                $("#rezultat4").text("Greska pri brisanju proizvoda!").css({color: "red"});
            }
        });

        $("#rezultat4").text("");
        return false;
    });
});