const express = require('express');

// Paket za parsiranje tela zahteva
const bodyParser = require('body-parser');

// Kreiramo module za svaku putanju
const productRoutes = require('./api/routes/products');

// Nasa aplikacija ce u osnovi biti express aplikacija
const app = express();

// Dodajemo mogucnosti body-parser paketa
app.use(bodyParser.urlencoded({
    extended: false // Zelimo samo jednostavne url encoded podatke da parsiramo
}));
app.use(bodyParser.json({
    // Ovde takodje mozemo konfigurisati
    // sta sve moze da se parsira
}));

// Da bismo resili CORS greske,
// moramo da pre obrade zahteva
// dodamo odgovarajuca zaglavlja
app.use(function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS')
    {
        res.header('Access-Control-Allow-Methods', 'OPTIONS, GET, POST, PATCH, DELETE');

        return res.status(200).json({});
    }

    // Ovaj poziv ce "proslediti" zahtev narednom middleware-u
    next();
});

// Za sve putanje koje pocinju sa "/products", 
// zelimo da koristimo productRoutes middleware
// koji smo mi kreirali
app.use('/products', productRoutes);

// Ako je na ovom mestu HTTP zahtev prosao,
// to znaci da nije uhvacen od strane gornjih 'use' poziva.
// To znaci da je klijent poslao zahtev koji nismo definisali,
// pa mozemo da mu vratimo, na primer, 405 statusni kod
app.use(function(req, res, next) {
    const error = new Error('Zahtev nije podrzan od servera');
    error.status = 405;

    // Sada moramo da prosledimo nasu kreiranu gresku,
    // da bi se prikazao umesto podrazumevanog,
    // pa pozivamo naredni middleware,
    // sto je u ovom slucaju funkcija ispod
    next(error);
});

// Dodajemo jos jedan nivo hvatanja gresaka,
// za sve ostale greske, tipa: 
// 1. greske u kodu,
// 2. greske u bazi podataka.
// 3. ...
app.use(function(error, req, res, next) {
	res.status(error.status || 500).json({
		greska: {
			poruka: error.message
		}
	});
});

module.exports = app;
