function skalarni_proizvod(x, y)
{
    let sp = 0;
    for (let i = 0; i < x.length; ++i)
    {
        sp += x[i] * y[i];
    }

    return sp;
}

module.exports.skalarni_proizvod = skalarni_proizvod;
