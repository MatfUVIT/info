const http = require('http');
const url = require('url');
const {skalarni_proizvod} = require('./skalarni-proizvod');

const server = http.createServer();
server.on('request', function(req, res)
{
    let teloOdgovora = {};
    let statusniKod = 200;

    let method = req.method;

    if (method === "GET")
    {
        let urlString = req.url;
        let urlObj = url.parse(urlString, true);
        let getPodaci = urlObj.query;
        let x = [getPodaci.x1, getPodaci.x2, getPodaci.x3];
        let y = [getPodaci.y1, getPodaci.y2, getPodaci.y3];

        let rezultat = skalarni_proizvod(x, y);

        res.setHeader('Content-Type', 'application/json');
        teloOdgovora = {rezultat};
    }
    else if (method === "OPTIONS")
    {
        res.setHeader('Access-Control-Allow-Methods', 'OPTIONS, GET');
    }
    else
    {
        statusniKod = 405;
        res.setHeader('Access-Control-Allow-Methods', 'OPTIONS, GET');
    }
	
	res.writeHead(statusniKod, {
		'Access-Control-Allow-Origin': '*',
		'Access-Control-Allow-Headers': 'Content-Type'
	});
	res.write(JSON.stringify(teloOdgovora));
	res.end();
});
	
const port = 3000;
server.listen(port);
server.once('listening', function()
{
	console.log(`http://localhost:${port}`);
});