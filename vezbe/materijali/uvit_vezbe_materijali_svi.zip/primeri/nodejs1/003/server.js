const http = require('http');

const app = require('./app');

// Mozemo dodeliti port kroz promenljivu okruzenja,
// a u slucaju da nije dostupna,
// bice postavljena vrednost 3000
const port = process.env.PORT || 3000;

const server = http.createServer(app);

server.listen(port);
server.once('listening', function() {
    console.log(`Listening on port ${port}`);
});
