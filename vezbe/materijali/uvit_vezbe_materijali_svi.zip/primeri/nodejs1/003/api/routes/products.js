const express = require('express');

const router = express.Router();

// Ne stavljamo /products,
// zato sto ce vec imati taj prefiks
// kad dodje do ove putanje,
// zbog app middlewear-a
router.get('/', function(req, res, next) {
    res.status(200).json({
        poruka: 'GET /products'
    });
});

router.post('/', function(req, res, next) {
    const kreiraniProizvod = {
        name: req.body.name,
        price: req.body.price
    };

    res.status(201).json({
        poruka: 'POST /products',
        kreiraniProizvod
    });
});

// Individualni

router.get('/:productId', function(req, res, next) {
    const productId = req.params.productId;

    if (productId === 'special')
    {
        res.status(200).json({
            poruka: 'Otkrili ste specijalni ID!',
            id: productId
        });
    }
    else
    {
        res.status(200).json({
            poruka: 'Prosledjen je ID: ' + productId
        });
    }
});

router.patch('/:productId', function(req, res, next) {
    res.status(200).json({
        poruka: 'Azuriran je proizvod'
    });
});

router.delete('/:productId', function(req, res, next) {
    res.status(200).json({
        poruka: 'Obrisan je proizvod'
    });
});

module.exports = router;
