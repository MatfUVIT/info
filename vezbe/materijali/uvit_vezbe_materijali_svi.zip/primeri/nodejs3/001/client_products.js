$(document).ready(function() {
    $("#form1").submit(function()
    {
        // Element u kojem ce biti ispisani bilo svi postojeci proizvodi,
        // bilo samo onaj ciji je identifikator prosledjen
        let listaProizvoda = $("#listaProizvoda");
        // Element u kojem ce biti ispisana greska
        let greska1 = $("#greska1");

        let productId = $("#productId1").val();

        if (productId === "")
        {
            $.ajax("http://localhost:3000/products", {
                method: "GET",
                success: function(data) {
                    if(data.hasOwnProperty("rezultat")) {
                        let sviProizvodi = data.rezultat;

                        if (sviProizvodi.length === 0)
                        {
                            listaProizvoda.html("<p>Nema proizvoda!</p>");
                            return;
                        }

                        for (let i = 0; i < sviProizvodi.length; ++i)
                        {
                            let proizvod = sviProizvodi[i];
                            let noviProizvod = kreirajNoviProizvod(proizvod, false);
                            listaProizvoda.append(noviProizvod);
                        }
                    }
                },
                error: function() {
                    greska1.text("Greska pri dohvatanju liste proizvoda!").css({color: "red"});
                }
            });
        }
        else
        {
            $.ajax(`http://localhost:3000/products/${productId}`, {
                method: "GET",
                success: function(data) {
                    let noviProizvod = kreirajNoviProizvod(data, true);
                    listaProizvoda.append(noviProizvod);
                },
                error: function() {
                    greska1.text("Greska pri dohvatanju trazenog proizvoda!").css({color: "red"});
                }
            });
        }

        // Cistimo elemente od rezultata poziva od prethodnog puta
        listaProizvoda.html("");
        greska1.text("");

        return false;
    });

    $("#form2").submit(function()
    {
        // Element u kojem ce biti prikazan kreirani proizvod
        let kreiraniProizvod = $("#kreiraniProizvod");
        let greska2 = $("#greska2");

        let name = $("#name").val();
        let price = Number.parseFloat($("#price").val());

        if (name === "")
        {
            greska2.text("Niste prosledili naziv proizvoda").css({color: "red"});
            return false;
        }

        if (Number.isNaN(price))
        {
            greska2.text("Niste prosledili ispravnu cenu proizvoda").css({color: "red"});
            return false;
        }

        $.ajax("http://localhost:3000/products", {
            method: "POST",
            data: {
                name, price
            },
            success: function(data) {
                if(data.hasOwnProperty("kreiraniProizvod")) {
                    let noviProizvod = kreirajNoviProizvod(data.kreiraniProizvod, true);
                    kreiraniProizvod.append(noviProizvod);
                }
            },
            error: function() {
                greska2.text("Greska pri postavljanju proizvoda!").css({color: "red"});
            }
        });

        kreiraniProizvod.html("");
        greska2.text("");

        return false;
    });

    $("#form3").submit(function()
    {
        let greska3 = $("#greska3");

        let productId = $("#productId3").val();

        if (productId === "")
        {
            greska3.text("Niste prosledili identifikator proizvoda").css({color: "red"});
            return false;
        }

        let name = $("#name2").val();
        let price = $("#price2").val();
        let updateOptions = [];

        if (name !== "")
        {
            updateOptions.push({
                nazivPolja: "name",
                novaVrednost: name
            });
        }

        if (price !== "")
        {
            updateOptions.push({
                nazivPolja: "price",
                novaVrednost: price
            });
        }

        console.log(updateOptions);
        
        $.ajax(`http://localhost:3000/products/${productId}`, {
            method: "PATCH",
            data: JSON.stringify(updateOptions),
            contentType: "application/json",
            success: function(data) {
                if(data.hasOwnProperty("poruka")) {
                    greska3.text(data.poruka).css({color: "green"});
                }
            },
            error: function() {
                greska3.text("Greska pri menjanju proizvoda!").css({color: "red"});
            }
        });

        greska3.text("");

        return false;
    });

    $("#form4").submit(function()
    {
        let greska4 = $("#greska4");

        let productId = $("#productId4").val();

        if (productId === "")
        {
            greska4.text("Niste prosledili identifikator proizvoda").css({color: "red"});
            return false;
        }
        
        $.ajax(`http://localhost:3000/products/${productId}`, {
            method: "DELETE",
            success: function(data) {
                if(data.hasOwnProperty("poruka")) {
                    greska4.text(data.poruka).css({color: "green"});
                }
            },
            error: function() {
                greska4.text("Greska pri brisanju proizvoda!").css({color: "red"});
            }
        });

        greska4.text("");
        return false;
    });
});

// Pomocna funkcija za kreiranje novog <div> elementa
function kreirajNoviProizvod(podaciOProizvodu, odabran)
{
    let naziv = podaciOProizvodu.name;
    let cena = podaciOProizvodu.price;
    let sku = podaciOProizvodu._id;

    let noviProizvod = $(document.createElement("div"));
    noviProizvod.addClass("proizvod");

    if (odabran === true)
    {
        noviProizvod.addClass("odabraniProizvod");
    }

    noviProizvod.html(`
        <h4>${naziv}</h4>
        <h5>Cena: ${cena}</h5>
        <p>${sku}</p>
    `);

    return noviProizvod;
}