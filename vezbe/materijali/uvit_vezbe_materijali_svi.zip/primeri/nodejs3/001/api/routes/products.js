const express = require('express');
const mongoose = require('mongoose');

const router = express.Router();

const Product = require('../models/product');

router.get('/', function(req, res, next) {
    Product.find({}, function(err, result)
    {
        if (err)
        {
            return res.status(500).json({reason: err});
        }

        res.status(200).json({
            rezultat: result
        });
    }).sort({name : 1, price : -1});
});

router.post('/', function(req, res, next) {
    // Pravimo novu instancu Product modela 
    // na osnovu prosledjenih parametara
    const product = new Product({
        _id: new mongoose.Types.ObjectId(),
        name: req.body.name,
        price: req.body.price
    });

    product.save(function(err, result) {
        if (err) 
        {
            return res.status(500).json({reason: err});
        }
        
        res.status(201).json({
            poruka: 'Proizvod je uspesno kreiran',
            kreiraniProizvod: result
        });
    });
});

// Individualni

router.get('/:productId', function(req, res, next) {
    const productId = req.params.productId;

    Product.findById(productId, function(err, result)
    {
        // Provera da li je doslo do greske
        if (err)
        {
            return res.status(500).json({reason: err});
        }

        // Provera da li je pronadjen objekat
        if (result)
        {
            return res.status(200).json(result);
        }
        
        // Ukoliko nije pronadjen objekat
        return res.status(404).json({poruka: "Ne postoji trazeni proizvod"});
    });
});

router.patch('/:productId', function(req, res, next) {
    const productId = req.params.productId;

    const updateOptions = {};
    for (let i = 0; i < req.body.length; ++i)
    {
        let option = req.body[i];
        updateOptions[option.nazivPolja] = option.novaVrednost;
    }
    
    Product.updateOne(
        {_id: productId},
        { $set: updateOptions },
        function(err, raw)
        {
            if (err)
            {
                return res.status(500).json({poruka: err});
            }

            res.status(200).json({poruka: "Proizvod je uspesno izmenjen"});
        }
    );
});

router.delete('/:productId', function(req, res, next) {
    const productId = req.params.productId;

    Product.deleteOne({_id: productId}, function(err)
    {
        if (err)
        {
            return res.status(500).json({poruka: err});
        }

        res.status(200).json({poruka: "Proizvod je uspesno uklonjen"});
    })
});

module.exports = router;
