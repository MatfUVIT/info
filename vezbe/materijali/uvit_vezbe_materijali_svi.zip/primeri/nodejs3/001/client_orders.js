$(document).ready(function() {
    
    $("#form5").submit(function()
    {
        let listaNarudzbina = $("#listaNarudzbina");
        let greska5 = $("#greska5");

        let orderId = $("#orderId1").val();

        if (orderId === "")
        {
            $.ajax("http://localhost:3000/orders", {
                method: "GET",
                success: function(data) {
                    let count = data.count;
                    let sveNarudzbine = data.orders;

                    if (count === 0)
                    {
                        listaNarudzbina.html("<p>Nema narudzbina!</p>");
                        return;
                    }

                    for (let i = 0; i < sveNarudzbine.length; ++i)
                    {
                        let tekucaNarudzbina = sveNarudzbine[i];
                        let novaNarudzbina = kreirajNovuNarudzbinuBezPodatakaOProizvodu(tekucaNarudzbina, false);
                        listaNarudzbina.append(novaNarudzbina);
                    }
                },
                error: function() {
                    greska5.text("Greska pri dohvatanju svih narudzbina!").css({color: "red"});
                }
            });
        }
        else
        {
            $.ajax(`http://localhost:3000/orders/${orderId}`, {
                method: "GET",
                success: function(data) {
                    let novaNarudzbina = kreirajNovuNarudzbinuSaPodacimaOProizvodu(data, true);
                    listaNarudzbina.append(novaNarudzbina);
                },
                error: function(jqXHR) {
                    // Objekat jqXHR ima svojstvo status kojim dobijamo statusni kod od servera
                    if (jqXHR.status === 404) 
                    {
                        // Objekat jqXHR ima svojstvo responseText kojim dobijamo sam odgovor od servera.
                        // Posto mi znamo da se odgovor salje kao JSON niska,
                        // onda mozemo da konvertujemo tu nisku u JavaScript objekat
                        // tako sto pozovemo funkciju JSON.parse, kojoj se prosledjuje JSON niska.
                        // Dakle, JSON.parse je inverzna funkcija funkcije JSON.stringify (vazi i obrnuto).
                        let odgovorOdServera = JSON.parse(jqXHR.responseText);
                        greska5.text(odgovorOdServera.poruka).css({color: "red"});
                    }
                    else 
                    {
                        greska5.text("Greska pri dohvatanju narudzbine!").css({color: "red"});
                    }
                }
            });
        }

        listaNarudzbina.html("");
        greska5.text("");

        return false;
    });

    $("#form6").submit(function()
    {
        let kreiranaNarudzbina = $("#kreiranaNarudzbina");
        let greska6 = $("#greska6");

        let productId = $("#productId5").val();
        let quantity = Number.parseInt($("#quantity").val());

        if (productId === "")
        {
            greska6.text("Niste prosledili identifikator proizvoda").css({color: "red"});
            return false;
        }

        if (Number.isNaN(price))
        {
            greska6.text("Niste prosledili ispravnu kolicinu proizvoda").css({color: "red"});
            return false;
        }

        $.ajax("http://localhost:3000/orders", {
            method: "POST",
            data: JSON.stringify({
                productId, quantity
            }),
            contentType: 'application/json',
            success: function(data) {
                let novaNarudzbina = kreirajNovuNarudzbinuBezPodatakaOProizvodu(data, true);
                kreiranaNarudzbina.append(novaNarudzbina);
            },
            error: function() {
                greska6.text("Greska pri postavljanju narudzbine!").css({color: "red"});
            }
        });

        kreiranaNarudzbina.html('');
        greska6.text('');

        return false;
    });
    

    $("#form7").submit(function()
    {
        let greska7 = $("#greska7");

        let orderId = $("#orderId2").val();

        if (orderId === "")
        {
            greska7.text("Niste prosledili identifikator narudzbine").css({color: "red"});
            return false;
        }
        
        $.ajax(`http://localhost:3000/orders/${orderId}`, {
            method: "DELETE",
            success: function(data) {
                if(data.hasOwnProperty("poruka")) {
                    greska7.text(data.poruka).css({color: "green"});
                }
            },
            error: function() {
                greska7.text("Greska pri brisanju proizvoda!").css({color: "red"});
            }
        });

        greska7.text("");

        return false;
    });
});

// Pomocne funkcije za kreiranje novog <div> elementa

function kreirajNovuNarudzbinuBezPodatakaOProizvodu(podaciONarudzbini, odabrana)
{
    let orderID = podaciONarudzbini._id;
    let productID = podaciONarudzbini.product;

    let novaNarudzbina = $(document.createElement("div"));
    novaNarudzbina.addClass("narudzbina");

    if (odabrana === true)
    {
        novaNarudzbina.addClass("odabranaNarudzbina");
    }

    novaNarudzbina.html(`
        <h4>ID proizvoda: ${productID}</h4>
        <p>${orderID}</p>
    `);

    return novaNarudzbina;
}

function kreirajNovuNarudzbinuSaPodacimaOProizvodu(podaciONarudzbini, odabrana)
{
    let orderID = podaciONarudzbini._id;
    let kolicina = podaciONarudzbini.quantity;
    let proizvod = podaciONarudzbini.product;

    let novaNarudzbina = $(document.createElement("div"));
    novaNarudzbina.addClass("narudzbina");

    if (odabrana === true)
    {
        novaNarudzbina.addClass("odabranaNarudzbina");
    }

    novaNarudzbina.html(`
        <h5>Proizvod: ${proizvod.name}</h5>
        <h5>Cena: ${proizvod.price}</h5>
        <p>Količina: ${kolicina}</p>
        <p>${orderID}</p>
    `);

    return novaNarudzbina;
}
