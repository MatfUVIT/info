const http = require('http');
const url = require('url');
const range = require('range');
const shuffle = require('shuffle-array');

const server = http.createServer();

server.on('request', function(req, res) {
    let teloOdgovora = {};
    let statusniKod = 200;

    let method = req.method;

    if (method === 'GET') 
    {
        // Izdvajanje podataka iz zahteva
        let urlString = req.url;
        let urlObj = url.parse(urlString, true);
        let data = urlObj.query;
        // Primetimo da ukoliko je vrednost podatka niz,
        // onda se na ime te vrednosti dodaju karakteri "[]",
        // te ne mozemo koristiti tacka-notaciju da dohvatimo taj niz
        let boxes = data["check[]"];
        let n = data.n;

        // Pravljenje nizova brojeva, malih i velikih slova
        let numbers = range.range(0, 10);
        let lower = new Array(26);
        let upper = new Array(26);

        for(let i = 0; i < 26; ++i) 
        {
            lower[i] = String.fromCharCode(97 + i);
            upper[i] = String.fromCharCode(65 + i);
        }

        // Niz koji sadrzi sve nizove koje smo generisali.
        // Primetimo da indeksi nizova moraju da odgovaraju indeksima odgovarajucim vrednostima u nizu boxes.
        // Dakle, "all" je niz nizova!
        let all = new Array();
        all.push(lower);
        all.push(upper);
        all.push(numbers);

        // Niz koji sadrzi samo dozvoljene karaktere
        let allowed = new Array();
        
        for(let i = 0; i < boxes.length; ++i) 
        {
            // Ako je odgovarajuce checkbox polje bilo ukljuceno
            if(boxes[i] === 'true') 
            {
                // Spoji prethodni niz sa nizom koji odgovara tom checkbox polju
                // i sacuvaj taj niz za narednu iteraciju.
                // Dakle, "allowed" je niz karaktera!
                allowed = allowed.concat(all[i]);
            }
        }
        
        // Nasumicno promesaj niz dozvoljenih karaktera i sacuvaj ga
        allowed = shuffle(allowed);

        // Prvo izdvoji prvih n karaktera u promesanom nizu
        let captcha = allowed.slice(0, n);
        // A zatim spoji te izdvojene karaktere u nisku,
        // pri cemu ce se spajanje vrsiti po praznoj niski.
        captcha = captcha.join("");

        res.setHeader('Content-Type', 'application/json');
        teloOdgovora = {captcha};
    }
    else if (method == 'OPTIONS') 
    {
        res.setHeader('Allow', 'OPTIONS, GET');
    }
    else 
    {
        statusniKod = 405;
        res.setHeader('Allow', 'OPTIONS, GET');
    }

    res.writeHead(statusniKod, {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type'
    });
    res.write(JSON.stringify(teloOdgovora));
    res.end();
});

const port = 3000;
server.listen(port);

server.once('listening', function() {
    console.log(`http://localhost:${port}`);
});
