const express = require('express');
const router = express.Router();

router.get('/', function(req, res, next) {
    res.status(200).json({
        poruka: 'Narudzbine su pristigle!'
    });
});

router.post('/', function(req, res, next) {
    const order = {
        productID: req.body.productID,
        quantity: req.body.quantity
    };

    res.status(201).json({
        poruka: 'Narudzbina je upisana',
        order: order
    });
});

router.get('/:orderID', function(req, res, next) {
    const orderID = req.params.orderID;

    res.status(200).json({
        poruka: 'Narudzbina ' + orderID + ' je pristigla'
    });
});

router.delete('/:orderID', function(req, res, next) {
    const orderID = req.params.orderID;

    res.status(200).json({
        poruka: 'Narudzbina ' + orderID + ' je obrisana'
    });
});

module.exports = router;
