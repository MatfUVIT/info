const express = require('express');
const mongoose = require('mongoose');

const Order = require('../models/order');
const Product = require('../models/product');

const router = express.Router();

router.get('/', function(req, res, next) {
    Order.find({}, function(err, result)
    {
        if (err)
        {
            return res.status(500).json({poruka: err});
        }

        res.status(200).json({
            count: result.length,
            orders: result
        });   
    }).select('product');
});

router.post('/', function(req, res, next) {
    Product.findById(req.body.productId, function (err, result) {
        if (err)
        {
            return res.status(500).json({poruka: err});
        }

        if (result === null)
        {
            return res.status(404).json({poruka: "Ne mozemo kreirati porudzbinu za nepostojeci proizvod"});
        }

        const order = new Order({
            _id: new mongoose.Types.ObjectId(),
            quantity: req.body.quantity,
            product: req.body.productId
        });
    
        order.save(function(err, result)
        {
            if (err)
            {
                return res.status(500).json({poruka: err});
            }
    
            res.status(201).json(result);
        });
    });
});

router.get('/:orderID', function(req, res, next) {
    const orderID = req.params.orderID;

    Order.findById(orderID, function(err, result)
    {
        if (err)
        {
            return res.status(500).json({poruka: err});
        }

        if (result)
        {
            res.status(200).json(result);
        }

        res.status(404).json({poruka: "Ne postoji trazena narudzbina"});
    });
});

router.delete('/:orderID', function(req, res, next) {
    const orderID = req.params.orderID;

    Order.deleteOne({_id: orderID}, function(err)
    {
        if (err)
        {
            return res.status(500).json({poruka: err});
        }

        res.status(200).json({poruka: "Narudzbina je uspesno uklonjena"});
    });
});

module.exports = router;
