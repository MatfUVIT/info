/* klijent program */

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>

/* port na kojem se uspostavlja komunikacija izmedju klijenta i servera */
#define PORT 9999

/* velicina bafera */
#define BUFFER_SIZE 80

/* funkcija koja ispisuje informaciju o nastaloj gresci i prekida izvrsavanje programa */
void error_fatal(char* msg){
	fprintf(stderr,"%s\n", msg);
	exit(EXIT_FAILURE);
}


int main(int argc, char** argv){

	/* deskriptor soketa za komunikaciju sa serverom */
	int server;
	
	/* struktura koja ce sadrzati informacije o IP adresi servera */
	struct hostent* host;
	
	/* struktura koja ce sadrzati mreznu adresu servera (IP adresa servera i PORT servera) */
	struct sockaddr_in address;
	
	/* prostor za poruku koju server salje */
	char buffer[BUFFER_SIZE];
	
	/* duzina poruke koju server salje */
	int count;

	/* proveravamo da li je korisnik uneo dovoljan broj argumenata */
	if(argc!=2)
		error_fatal("Greska prilikom poziva!");

	/* kreiramo soket za komunikaciju sa serverom */
	server=socket(PF_INET, SOCK_STREAM, 0);
	if(server<0)
		error_fatal("socket() error");

	/* odredjujemo IP adresu servera na osnovu zadatog mreznog imena */
	host=gethostbyname(argv[1]);
	if(host==NULL)
		error_fatal("gethostbyname() error");

	/* popunjavamo strukturu koja odredjuje mreznu adresu servera */
	address.sin_family=AF_INET;
	address.sin_port=htons(PORT);
	memcpy(&address.sin_addr.s_addr, host->h_addr_list[0], host->h_length);

	
	/* povezujemo se sa serverom */
	if(connect(server, (struct sockaddr*) &address, sizeof(address))<0)
		error_fatal("connect() error");

	/* citamo informaciju o vremenu koju je server poslao */
	count=read(server, buffer, BUFFER_SIZE-1);
	if(count<0)
		error_fatal("read() error");
	
	buffer[count]='\0';

	/* i ispisujemo je na standardni izlaz */
	fputs(buffer, stdout);

	/* prekidamo konekciju sa serverom */
	if(close(server)<0)
		error_fatal("close() error");


	/* zavrsavamo program */
	exit(EXIT_SUCCESS);	
}
