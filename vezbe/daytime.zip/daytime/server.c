/* server program */
/* u pitanju je implementacija za konkurentni server */

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <unistd.h>
#include <time.h>
#include <netinet/in.h>
#include <strings.h>
#include <string.h>

/* port na kojem se uspostavlja komunikacija izmedju klijenta i servera */
#define PORT 9999

/* velicina bafera */
#define BUFFER_SIZE 80


/* funkcija koja ispisuje informaciju o nastaloj gresci i prekida izvrsavanje programa */
void error_fatal(char* msg){
	fprintf(stderr,"%s\n", msg);
	exit(EXIT_FAILURE);
}


int main(int argc, char** argv){

	/* deskriptor soketa servera */
	int server;
	
	/* struktura koja ce sadrzati mreznu adresu servera (IP adresa servera i PORT servera) */
	struct sockaddr_in address;
	
	/* deskriptor soketa za komunikaciju sa klijentom */
	int client;
	
	/* id procesa */
	int pid;


	/* kreiramo soket servera */
	server=socket(PF_INET, SOCK_STREAM, 0);
	if(server<0)
		error_fatal("socket() error");

	/* popunjavamo strukturu koja predstavlja mreznu adresu servera */
	bzero(&address, sizeof(struct sockaddr_in));
	address.sin_family=AF_INET;
	address.sin_port=htons(PORT);
	address.sin_addr.s_addr=htonl(INADDR_ANY);
	
	/* vezemo adresu servera za soket servera */
	if(bind(server, (struct sockaddr*)&address, sizeof(struct sockaddr_in))<0)
		error_fatal("bind() error");
	
	/* postavljamo soket servera na cekanje */
	if(listen(server, 5)<0)
		error_fatal("listen() error");

	
	/* u petlji.. */
	for(;;){

		/* prihvatamo zahtev od klijenta */
		client=accept(server, NULL, NULL);
		if(client<0)
			error_fatal("accept() error");
		
		/* kreiramo novi proces koji ce opsluzivati klijenta */
		pid=fork();
		
		/* nadalje razlikujemo dete proces i roditelj proces */
		if(pid<0)
			error_fatal("fork() error");

		if(pid==0){
		
			/* dete proces */

			/* zatvaramo soket za komunikaciju sa serverom */
			if(close(server)<0)
				error_fatal("close() error");

			/* ocitavamo koliko ima sati */
			time_t now;
			char buffer[BUFFER_SIZE];
			
			time(&now);

			/* procitano vreme zapisujemo kao nisku */
			snprintf(buffer, BUFFER_SIZE, "%s", ctime(&now));
	
			/* i saljemo je klijentu */
			if(write(client, buffer, strlen(buffer))<0)
				printf("write() error");

			/* zatvorimo klijentski soket */
			if(close(client)<0)
				error_fatal("close() error");

			/* i zavrsavamo sa procesom */
			exit(EXIT_SUCCESS);		
		
		}
		else{
			/* roditelj proces */
			
			/* zatvaramo soket za komunikaciju sa klijentom */
			if(close(client)<0)
				error_fatal("close() error");

			
		}
	
	
	
	}
	
}
