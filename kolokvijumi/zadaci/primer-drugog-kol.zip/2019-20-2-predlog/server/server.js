const http = require('http');

const server = http.createServer(function (req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Content-Type', 'application/json');

    if (Math.random() < 0.5) {
        res.statusCode = 200;
        return res.end('{"id":"0001","type":"donut","name":"Cake","ppu":0.55,"batters":{"batter":[{"id":"1001","type":"Regular"},{"id":"1002","type":"Chocolate"},{"id":"1003","type":"Blueberry"},{"id":"1004","type":"DevilsFood"}]},"topping":[{"id":"5001","type":"None"},{"id":"5002","type":"Glazed"},{"id":"5005","type":"Sugar"},{"id":"5007","type":"PowderedSugar"},{"id":"5006","type":"ChocolatewithSprinkles"},{"id":"5003","type":"Chocolate"},{"id":"5004","type":"Maple"}]}');
    } else {
        res.statusCode = 500;
        return res.end('{"poruka":"Došlo je do greške na serveru"}', 'UTF-8');
    }
});

const port = 3000;
server.listen(port);

console.log('Server je pokrenut na adresi http://localhost:' + port);