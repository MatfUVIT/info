
let dugmici = document.querySelectorAll('input[type="button"]');
console.log(dugmici,length);
let knjiga = document.querySelector('#knjiga');
let lista_slika = ['1.jpg', '2.jpg'];
let current_position = 0;
dugmici[0].addEventListener('click', function(){
    console.log("kliknuto je levo dugme");
    if (current_position-1 >=0)
        current_position--;
    else
        current_position = lista_slika.length-1;
    console.log(current_position);
    knjiga.style.backgroundImage="url("+lista_slika[current_position]+")";
    
});

dugmici[2].addEventListener('click', function(){
    console.log("kliknuto je desno dugme");
    if (current_position+1 < lista_slika.length)
        current_position++;
    else 
        current_position=0;
    console.log(current_position);
    knjiga.style.backgroundImage="url("+lista_slika[current_position]+")";
    
});


knjiga.addEventListener('click', function(){
    console.log('kliknuta je knjiga');
});

knjiga.addEventListener('mouseover', function(){
	let kupi=document.querySelector("#kupi");
	kupi.style.display = "block";
});

knjiga.addEventListener('mouseout', function(){
	let kupi=document.querySelector("#kupi");
	kupi.style.display = "none";
});
