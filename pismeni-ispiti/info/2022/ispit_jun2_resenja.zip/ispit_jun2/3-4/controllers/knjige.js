
let KupovinaModel = require('../models/kupovine');
let KnjigaModel = require('../models/knjige')
// 3. zadatak
async function prikaziPocetnuStranicu(req, res, next) {
   
    res.render('pocetna.ejs');
}

// 3. zadatak 
async function prikaziKnjige(req, res, next) {
    
    let username = req.body.username;
    console.log("username"+username);
    let password = req.body.lozinka;
    console.log("password"+password);
    let result= await KupovinaModel.dohvatiKnjigeZaKorisnika(username, password);
    
    //console.log(result);
    
    res.render('knjige.ejs',{result, username:username, password});
  
}


// 4. zadatak
async function prikaziRezultatePretrage(req, res, next) {
    let username = req.query.username;
    let password = req.query.lozinka;
    let zanr = req.query.zanr;
    let cena_min;
    let cena_max;
    if (isNaN(Number.parseInt(req.query.min_cena)))
        cena_min =0;
    else 
        cena_min=Number.parseInt(req.query.min_cena);
    if (isNaN(Number.parseInt(req.query.max_cena)))
        cena_max =100000;
    else 
        cena_max=Number.parseInt(req.query.max_cena);
    let result =await KnjigaModel.dohvatiKnjigeNaprednaPretraga(username,password, zanr, cena_min, cena_max);
    res.render('knjige.ejs',{result, username, password});
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziKnjige,
    prikaziRezultatePretrage	
};
