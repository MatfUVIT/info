const path = require("path");
const express = require("express");
const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/Knjizara", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).catch(error => handleError(error));

const knjigeRoutes = require("./routes/knjige");

const app = express();

app.set("view engine", "ejs");
app.set("views", "views");


//ovaj deo je za cors error i student ga moze dobiti na ispitu
//ako zatrazi
app.options("/", (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "http://127.0.0.1:5500");
    res.setHeader("Access-Control-Allow-Methods", "POST, GET, PUT");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.sendStatus(204);
  });

app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));

app.use("", knjigeRoutes);


app.use(function (req, res, next) {
    const err = new Error("Pokušali ste da učitate stranicu koja ne postoji: " + req.url);
    err.status = 404;

    next(err);
});

// eslint-disable-next-line no-unused-vars
app.use(function (error, req, res, next) {
    console.error(error.stack);

    const statusCode = error.status || 500;
    res.status(statusCode).json({
        errorMessage: error.message,
        errorCode: statusCode,
    });
});

module.exports = app;
