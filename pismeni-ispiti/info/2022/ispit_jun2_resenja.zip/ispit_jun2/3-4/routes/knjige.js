const express = require("express");
const kontroler = require("../controllers/knjige");

const router = express.Router();
router.get("/knjige/pretraga", kontroler.prikaziRezultatePretrage);
router.post("/knjige", kontroler.prikaziKnjige);
router.get("/",kontroler.prikaziPocetnuStranicu);


module.exports = router;
