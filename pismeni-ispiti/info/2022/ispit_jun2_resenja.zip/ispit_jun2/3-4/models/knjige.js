
const mongoose = require('mongoose');
const { Kupovina } = require('./kupovine');

let KupovinaModel = require('./kupovine');

// 4. zadatak//
async function dohvatiKnjigeNaprednaPretraga(username, password, zanr, cena_min, cena_max){
    let ids = await Kupovina.find({username, password},{_id_knjige:true, _id:false}).exec();
    let result = [];
   console.log("ids"+ids);
   console.log("params", zanr, cena_min, cena_max);
    for (let id of ids){
        let new_book = await KupovinaModel.Knjiga.findById(id._id_knjige).exec();
        console.log("new_book"+new_book);
        if (new_book.zanr === zanr && new_book.cena >= cena_min && new_book.cena <=cena_max)
                result.push(new_book);
    }


        result.sort(function(a,b){
            
            
            let    x= a.naziv.toLowerCase();
        
            let y = b.naziv.toLowerCase();
            if (x < y) {return -1;}
            if (x > y) {return 1;}
            return 0;
        });
    console.log(result);
    return result;
}


module.exports = {
    dohvatiKnjigeNaprednaPretraga
};
