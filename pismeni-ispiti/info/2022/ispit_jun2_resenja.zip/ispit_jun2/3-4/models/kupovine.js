const mongoose = require('mongoose');
const kupovineSchema = new mongoose.Schema({
    _id : mongoose.SchemaTypes.ObjectId,
    username: {
            type: mongoose.SchemaTypes.String,
            required: true
    },
    password:{
        type:String,
        required: true
    },
    
    _id_knjige:{
        type:mongoose.SchemaTypes.ObjectId,
        required: true
    }
    
}, {collection:"kupovine"});

const Kupovina = mongoose.model("Kupovine", kupovineSchema);

const knjigaSchema = new mongoose.Schema({
    _id :mongoose.SchemaTypes.ObjectId ,
    zanr: {
            type: mongoose.SchemaTypes.String,
            required: true
    },
    naziv:{
        type:String,
        required: true
    },
    autor:{
        type:String,
        required: true
    },
    datum:{
        type:mongoose.SchemaTypes.Date,
        required: true
    },
    cena:{
        type:Number,
        required: true
    },
    slika:{
        type:String,
        required: true
    }
    
}, {collection:"knjige"});

const Knjiga = mongoose.model("Knjige", knjigaSchema);

//let KnjigaModel = require('./knjige');
// 3. zadatak
async function dohvatiKnjigeZaKorisnika(username, password) {
    let ids = await Kupovina.find({username, password},{_id_knjige:true, _id:false}).exec();
    let result = [];
   
    for (let id of ids){
        let new_book = await Knjiga.findById(id._id_knjige).exec();
        console.log("new_book"+new_book);
       // if (new_book.length!==0)
        result.push(new_book);
    }

    result.sort(function(a,b){
        let x= a.naziv.toLowerCase();
    
        let y = b.naziv.toLowerCase();
        if (x < y) {return -1;}
        if (x > y) {return 1;}
        return 0;
    });
    
    //console.log(result);
    return result;
}

module.exports = {
    dohvatiKnjigeZaKorisnika,
    Kupovina,
    Knjiga
};
