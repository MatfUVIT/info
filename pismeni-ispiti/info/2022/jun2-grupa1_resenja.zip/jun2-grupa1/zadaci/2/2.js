function toString() {
    return `${this.imePrezime} ima prosecnu ocenu ${this.prosek} na smeru ${this.smer}`;
}

const studenti = [
    {
        id: 1,
        imePrezime: "Pera Peric",
        prosek: 10.0,
        smer: "I",
        upisan: true,
        toString,
    },
    {
        id: 2,
        imePrezime: "Laza Lazic",
        prosek: 9.21,
        smer: "M",
        upisan: false,
        toString,
    },
    {
        id: 3,
        imePrezime: "Pera Peric",
        prosek: 8.17,
        smer: "M",
        upisan: true,
        toString,
    },
    {
        id: 4,
        imePrezime: "Pera Peric",
        prosek: 9.5,
        smer: "A",
        upisan: true,
        toString,
    },
    {
        id: 5,
        imePrezime: "Pera Peric",
        prosek: 7.0,
        smer: "I",
        upisan: true,
        toString,
    },
    {
        id: 6,
        imePrezime: "Pera Peric",
        prosek: 8.04,
        smer: "I",
        upisan: false,
        toString,
    },
];

function napraviIzgled(div1){
    
    if (div1!== null){
      
        for (let stud of studenti){
            let elem1 = document.createElement('input');
            elem1.type ="checkbox";

            
            let lelem1 = document.createElement('label');
            let ltext = document.createTextNode(stud.toString());
            lelem1.appendChild(ltext);
            lelem1.style.textDecoration="line-through";
            console.log(stud.toString());
            div1.appendChild(elem1);
            div1.appendChild(lelem1);
            elem1.addEventListener('change', (event)=>{
                if (event.currentTarget.checked){
                    lelem1.style.textDecoration="none";
                } else{
                    lelem1.style.textDecoration="line-through";
                }
            });
            div1.appendChild(document.createElement('br'));

        }

    }
}
const body = document.getElementsByTagName('body');
let div1 = document.getElementById('div1');
napraviIzgled(div1);