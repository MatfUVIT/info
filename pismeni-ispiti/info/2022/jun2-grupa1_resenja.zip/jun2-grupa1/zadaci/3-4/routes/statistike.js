const express = require("express");

const router = express.Router();
const statistikeController = require('../controllers/statistike.js');
router.post('/unesi-statistiku', statistikeController.unesiStatistiku);
router.get('/prikazi-statistike', statistikeController.prikaziPocetnuStranicu);
router.get('/',statistikeController.prikaziStatistike);

module.exports = router;
