// Za 3. zadatak

const statistikeModel = require('../models/statistika.js');

async function prikaziPocetnuStranicu(req, res, next) {
    const smer = req.query.smer;
    console.log(smer);
    let nadjeni_smer = await statistikeModel.dohvatiIstorijuStatistikaZaSmer(smer);
    let statistike = nadjeni_smer;
    nadjeni_smer=nadjeni_smer[0];
    
    let brStudenata = nadjeni_smer.brojStudenata;
    let prosek = nadjeni_smer.prosek;
    let najStudent = nadjeni_smer.student;
    let nazivSmera = nadjeni_smer.smer;
    res.render('pocetna.ejs', {
        brStudenata,
        prosek,
        najStudent,
        nazivSmera,
        statistike
    });
    


}

// Za 3. zadatak
async function prikaziStatistike(req, res, next) {
    res.render('statistike.ejs', {
    });
}

// Za 4. zadatak
async function unesiStatistiku(req, res, next) {
    console.log("hello");
    const smer = req.body.smer;
    const brojStudenata =req.body.bstud;
    const student=req.body.student;
    const prosek=req.body.pocena;
    const datum=req.body.datum;
    let imaKomentar=req.body.imaKomentar;
    let komentar;
    
    console.log("imaKomentar " + imaKomentar);
    if (imaKomentar.checked){
        imaKomentar=true;
        komentar=req.body.komentar;
    }else{
        imaKomentar = false;
        komentar="";
    }
        
    await statistikeModel.unesiStatistikuZaSmer(smer, brojStudenata,prosek,student, datum, imaKomentar, komentar);

    res.redirect("http://localhost:3000/statistike/");
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziStatistike,
    unesiStatistiku,
};
