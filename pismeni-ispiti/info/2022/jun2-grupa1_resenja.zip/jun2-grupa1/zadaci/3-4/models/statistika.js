const mongoose = require('mongoose');

let statistikaSchema = new mongoose.Schema({
    smer: { type:String,
            required: true 
    },
    brojStudenata: {type: Number,
                required: true},
    prosek:{type:Number,
            required:true},
    datum:{
        type: mongoose.SchemaTypes.Date,
        required: true
    },
    student:{
        type:String,
        required: true
    },
    imaKomentar: Boolean,
    komentar:{
        type:String
    }
}, {collection: "statistike"}
);
const statistikaModel = mongoose.model("Statistika", statistikaSchema);



// Za 3. zadatak
async function dohvatiIstorijuStatistikaZaSmer(smer) {
    let nadjeni = await statistikaModel.find({smer: smer}).sort({datum:-1});
    console.log(nadjeni.smer);
    if (nadjeni.length === 0){
        return null;
    } else return nadjeni;
}

// Za 4. zadatak
async function unesiStatistikuZaSmer(smer, brojStudenata, prosek, student, datum, imaKomentar, komentar) {
    await statistikaModel.insertMany({smer, brojStudenata, prosek, student, datum, imaKomentar, komentar});
}

module.exports = {
    dohvatiIstorijuStatistikaZaSmer,
    unesiStatistikuZaSmer,
};
