
const mongoose = require('mongoose');

let upisanSchema = new mongoose.Schema({
    smer: { type:String,
            required: true 
    },
    imePrezime: {type: String,
                required: true},
    prosek:{type:Number,
            required:true},
    upisani: {type:Boolean,
            required: true}
}, {collection: "upisaniStudenti"}
);
const upisaniModel = mongoose.model("UpisanStudent", upisanSchema);

// Za 3. zadatak
async function dohvatiTekucuStatistikuZaSmer(smer) {
    
}

module.exports = {
    dohvatiTekucuStatistikuZaSmer,
};
