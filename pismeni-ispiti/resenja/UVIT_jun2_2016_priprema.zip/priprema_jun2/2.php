<html>
	<head>
		<title> 2 </title>
		<meta charset='utf-8'> 
	</head>
	
	<body>
		<?php
			include "funkcije.php";
			
			konektuj_se();

			/* Sifra, datum i vreme ispita */			
			$sifra="";
			$datum="";
			$vreme="";
			
			if(isset($_GET['zakazi'])){
				
				//ocitati sifru
				$sifra=$_GET['sifra'];
				
				//ocitavamo termin
				//termin je oblika 10.jun 15
				$termin=$_GET['termin'];
				$podaci=explode(" ", $termin);
				$datum=$podaci[0];
				$vreme=$podaci[1];
				
				//ocitavamo broj studenata
				$broj_studenata=$_GET['broj_studenata'];
				
				//azuriramo podatke
				$upit="
						update konsultacije
						set broj_studenata = broj_studenata + $broj_studenata
						where sifra='$sifra' and datum='$datum' and vreme='$vreme'				
				";
			}
			
			if(isset($_GET['zakazi_novi'])){
				//ocitati sifru
				$sifra=$_GET['sifra'];
				
				//ocitati datum
				$datum=$_GET['datum'];
				
				//ocitati vreme
				$vreme=$_GET['vreme'];
				
				//ocitati broj studenata
				$broj_studenata=$_GET['broj_zainteresovanih_studenata'];
				
				//upisujemo podatke
				$upit="insert into konsultacije values 
							('$sifra', '$datum', '$vreme', $broj_studenata)";							
			}
			
			if($sifra!="" and $datum!="" and $vreme!=""){
				$rezultat=mysqli_query($veza, $upit) 
					or die("Problem sa upitom...");
				
				if($rezultat){
					echo "Podaci su uspesno zabelezeni <br> ";
					//TODO: 				
					$upit_prebroj="select broj_studenata as 'broj' 
								from konsultacije
								where sifra='$sifra' and datum='$datum' and vreme='$vreme'";
				
					$rezultat_prebroj=mysqli_query($veza, $upit_prebroj) 
						or  die("Problem sa upitom za prebrojavanje....");
				
					$red=mysqli_fetch_assoc($rezultat_prebroj);
					$broj=$red['broj'];
				
					echo "Ukupan broj studenata je $broj ";
				
				}
				else{
					echo "Doslo je do greske!";
				}	
			}
			
			diskonektuj_se();
		?>
	
	</body>
</html>
