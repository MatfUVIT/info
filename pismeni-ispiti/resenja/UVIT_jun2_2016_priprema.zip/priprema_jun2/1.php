<html>
	<head>
		<title> 1 </title> 
		<meta charset='utf-8'> 
		<style type='text/css'>
			#deo_2{
				display: none;
			}
			
			.greska{
				color: red;
			}
			
			#deo_2_2{
				display: none;
			}
			
		</style>
		<script type='text/javascript' src='jquery-2.2.3.min.js'> </script> 
		<script>
			$(document).ready(function(){
			
				$("#dugme").click(function(){
					var sifra=$("#sifra").val();
					
					if(sifra==""){
						window.alert("Sifra je obavezna!");
						return;
					}
					
					if(sifra.length>10){
						window.alert("Duzina treba da bude manja od 10");
						return;
					}
					
					if(sifra.indexOf(" ")!=-1){
						window.alert("Sifra ne sme da sadrzi beline");
						return;
					}
				
					//ajax 
					$.ajax({
						url: "konsultacije.php", 
						method: "GET", 
						data: {sifra: sifra}, 
						success: function(rezultat){
							$("#dugmici").html(rezultat);
							$("#deo_2").show();
						}										
					});									
				});
				
				$("#ne_odgovara").click(function(){
					if($(this).is(":checked")){
						$("#deo_2_2").fadeIn();
					}
					else{
						$("#deo_2_2").fadeOut();
					}
				
				});
			
				$("#zakazi").click(function(){
					
					var obelezeno=false;
					$("input[name='termin']").each(function(){
						if($(this).is(":checked")){
							obelezeno=true;
							return;
						}				
					});
					
					if(!obelezeno){
						window.alert("Morate obeleziti termin!");
						return false;
					}
					
					var broj_studenata=parseInt($("#broj_studenata").val());
					if(isNaN(broj_studenata) || broj_studenata<1){
						window.alert("Morate uneti broj studenata");
						return false;
					}
				
				});
				
				
				$("#zakazi_novi").click(function(){
					var datum=$("#datum").val();
					var r=new RegExp("^[0-9][0-9]\.[a-z]+$");
					if(!r.test(datum)){
						$("#datum_greska").text("Pogresan datum!");
						return false;
					}
					else{
						$("#datum_greska").text("");
					}
					
					var vreme=parseInt($("#vreme").val());
					if(isNaN(vreme) || vreme<10 || vreme>20){
						$("#vreme_greska").text("Pogresno vreme!");
						return false;
					}
					else{
						$("#vreme_greska").text("");
					}
					
					var broj_zainteresovanih_studenata=parseInt($("#broj_zainteresovanih_studenata").val());
					if(isNaN(broj_zainteresovanih_studenata) || broj_zainteresovanih_studenata<1){
						$("#broj_zainteresovanih_studenata_greska").text("Pogresna vrednost");				
						return false;
					}
					else{
						$("#broj_zainteresovanih_studenata_greska").text("");				
					}
				});			
			
			});
		
		</script>
	</head>
	
	<body>
		<form action='2.php' method='GET'>
			<div id='deo_1'>
				sifra: <input type='text' name='sifra' id='sifra'> 
				<input type='button' value='prikazi termine' id='dugme'>
			</div> 
		
			<div id='deo_2'>
				<div id='dugmici'></div> 
		
				broj novih studenata: <input type='number' id='broj_studenata' name='broj_studenata'> 
				<br> 
				<br> 
				<input type='submit' id='zakazi' name='zakazi' value='zakazi'> 
								
				<br>
				<input type='checkbox' 
					name='ne_odgovara' id='ne_odgovara'> ni jedan termin nam ne odgovara
				<div id='deo_2_2'>
					<br>
					<br>
					datum: 
					<input type='text' name='datum' id='datum'> 
					<span class='greska' id='datum_greska'> </span>
					<br>
					vreme: 
					<input type='text' name='vreme' id='vreme'>
					<span class='greska' id='vreme_greska'> </span>
					<br>
					broj zainteresovanih studenata: 
					<input type='number' id='broj_zainteresovanih_studenata' 
										name='broj_zainteresovanih_studenata'> 
					<span class='greska' id='broj_zainteresovanih_studenata_greska'> </span>									
									
					<br>
					<br> 
					<input type='submit' id='zakazi_novi' 
							name='zakazi_novi' value='zakazi novi termin'> 
				</div>
			</div>
		</form>
		
		
	</body>
</html>
