<?php

	function konektuj_se(){
		global $veza;
		
		$veza=mysqli_connect("localhost", "veb", "veb", "fakultet");
		if(mysqli_connect_errno()){
			die("Problem sa povezivanjem: ".mysqli_connect_error());
		}
	}
	
	function diskonektuj_se(){
		global $veza;
		mysqli_close($veza);
	}

?>
