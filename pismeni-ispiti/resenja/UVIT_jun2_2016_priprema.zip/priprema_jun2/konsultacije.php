<?php

	include "funkcije.php";
	
	if(!isset($_GET['sifra'])){
		die("Greska");
	}
	
	$sifra=$_GET['sifra'];
	
	konektuj_se();
	
	$upit="select datum, vreme from konsultacije where sifra='$sifra'";
	$rezultat=mysqli_query($veza, $upit);
	
	while($red=mysqli_fetch_assoc($rezultat)){
		$datum=$red['datum'];
		$vreme=$red['vreme'];
		
		echo "<input type='radio' 
						name='termin' 
						value='$datum $vreme'> 
						$datum u $vreme h <br>";
	
	
	}
		
	diskonektuj_se();
	
	

?>
