const korisnici = [
  { ime: 'Rowan', prezime: "O'Connor" },
  { ime: 'Melody', prezime: 'Norton' },
  { ime: 'Minnie', prezime: 'Terry' },
  { ime: 'Damien', prezime: 'Roach' },
  { ime: 'Ida', prezime: 'Macdonald' },
  { ime: 'Zak', prezime: 'Carlson' },
  { ime: 'Nevaeh', prezime: 'Randolph' },
  { ime: 'Dewi', prezime: 'Sanford' },
  { ime: 'Michelle', prezime: 'Rhodes' },
  { ime: 'Oscar', prezime: 'Carter' },
];

const ol_array = document.querySelectorAll('#lista');
if (ol_array.length !== 0) {
  let ol = ol_array[0]
  for (let i = 0; i < korisnici.length; i++) {
    let li = document.createElement("li")
    ol.appendChild(li)
    li.textContent = korisnici[i].ime + ' ' + korisnici[i].prezime
    li.onclick = ()=>{
      li.style.color = "red"
      setTimeout(()=>{
        ol.removeChild(li)
      }, 2000)
    }
  }
}

