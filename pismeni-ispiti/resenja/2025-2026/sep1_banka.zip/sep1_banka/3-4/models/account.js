const mongoose = require('mongoose');

const accountSchema = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    ime: {
        type: String,
        required: true
    },
    prezime: String,
    stanje: {
        type: Number,
        required: true,
        default: 0
    }
}, { collection: "accounts" })

const AccountModel = mongoose.model('Account', accountSchema)

module.exports.model = AccountModel

module.exports.getAccounts = async function () {
    const accounts = await AccountModel.find().sort({"ime": 1}).exec()
    return accounts
};

module.exports.createAccount = async function (ime, prezime, stanje) {
    const newAccount = new AccountModel()
    newAccount._id = new mongoose.Types.ObjectId()
    newAccount.ime = ime
    newAccount.prezime = prezime
    newAccount.stanje = stanje

    const accountFromDB = await newAccount.save()

    return accountFromDB
};

module.exports.executeTransaction = async function (_id, kolicina, tip) {
    if(tip === "podigni") {
        kolicina = -kolicina
    }
    await AccountModel.updateOne({"_id": _id}, {
        $inc: {
            "stanje": kolicina
        }
    }).exec()

};