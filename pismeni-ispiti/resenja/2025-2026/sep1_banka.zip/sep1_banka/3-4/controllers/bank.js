const accountModel = require('../models/account');

module.exports.prikaziTabelu = async function (req, res, next) {
    try {        
      const accounts = await accountModel.getAccounts()
      return res.render('1.ejs', { accounts })
    } catch (err) {
        next(err);
    }
};

module.exports.dodajNalog = async function (req, res, next) {
  try {
    const imePrezime = req.body.ime
    const stanje = req.body.stanje
    const imePrezimeSplit = imePrezime.split(' ')
    const ime = imePrezimeSplit[0]
    const prezime = imePrezimeSplit[1]
    await accountModel.createAccount(ime, prezime, stanje)
    const accounts = await accountModel.getAccounts()
    return res.render('1.ejs', { accounts })
  } catch (err) {
      next(err);
  }
};

module.exports.prikaziBankomat = async function (req, res, next) {
  try {        
    const accounts = await accountModel.getAccounts()
    return res.render("4.ejs", { accounts })
  } catch (err) {
      next(err);
  }
};

module.exports.transakcija = async function (req, res, next) {
  try {        
    const _id = req.body.account
    const kolicina = req.body.kolicina
    const tip = req.body.bankomat
    await accountModel.executeTransaction(_id, kolicina, tip)
    const accounts = await accountModel.getAccounts()
    return res.render('1.ejs', { accounts })
  } catch (err) {
      next(err);
  }
};