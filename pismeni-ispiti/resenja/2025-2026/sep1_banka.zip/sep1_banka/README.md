U nodeinstall.md se nalazi uputstvo za instaliranje/ažuriranje nodejs na verziju 22.
Ovo je urađeno jer postoje problemi sa node 14 i potrebnim paketima sa npm.

U mongoimport.md se nalazi komanda za kreiranje baze podataka iz fajla bank.json.

Ovo je samo jedno od mogućih rešenja. Ako primetite greške javite se predmetnom asistentu.