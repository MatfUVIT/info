$(document).ready(function () {
    $('#formular').submit(function (ev) {
        let validacija = true;

        const id = $('#id').val();
        
        // TODO: validacija za id 
        
        if (!validacija) {
            ev.preventDefault();
            window.alert('Identifikator nije ispravan');
            $('#id').focus();
            return false;
        }

        const ime_prezime = $('#ime_prezime').val();
        
        // TODO: validacija za ime_prezime
        
        if (!validacija) {
            ev.preventDefault();
            window.alert('Polje za ime i prezime nije validno');
            $('#ime_prezime').focus();
            return false;
        }

        const broj = $('#broj_artikala').val();
        
        // TODO: validacija za broj_artikala 
        
        if (!validacija) {
            ev.preventDefault();
            window.alert('Broj artikala nije ispravan');
            $('#broj_artikala').focus();
            return false;
        }

        const datum_isporuke = $('#datum_isporuke').val();
        
        // TODO: validacija za datum_isporuke 
        
        if (!validacija) {
            ev.preventDefault();
            window.alert('Datum isporuke nije ispravan');
            $('#datum_isporuke').focus();
            return false;
        }
    });
});