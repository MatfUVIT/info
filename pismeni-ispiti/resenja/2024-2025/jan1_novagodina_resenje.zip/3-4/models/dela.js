const mongoose = require('mongoose');

const shema = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    ime:{
        type: String,
        required: true
    },
    dobro: Boolean,
    delo: String,
    poeni: Number,
    pismo: String,
    poslato: Boolean
},{collection:'dela'})

const model = mongoose.model('dela',shema)
//----------------------------------------

// 3. zadatak // ok
async function dohvatiDela(){
    let dela = await model.find().sort({poeni: -1}).exec()
    // console.log(dela)

    return dela
}

// 3. zadatak
async function dohvatiDelaPoImenu(ime){
    let dela = await model.find({ime: ime}).sort({poeni: 1}).exec()
    return dela[0]
}

// ok
async function sacuvajDelo(dete, delo, poeni) {
    const red = new model()
    red._id = new mongoose.Types.ObjectId()
    red.ime = dete 
    red.delo = delo 
    red.poeni = poeni 
    // red.dobro = Number.parseInt(poeni) < 0 ? false : true
    red.dobro = poeni < 0 ? false : true

    await red.save()
}

module.exports = {
    dohvatiDela,
    dohvatiDelaPoImenu,
    sacuvajDelo
};