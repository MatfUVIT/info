const express = require('express');

const controller = require('../controllers/rent');

const router = express.Router();

module.exports = router;