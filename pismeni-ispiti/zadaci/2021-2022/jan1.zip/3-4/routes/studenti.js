const express = require("express");
const kontroler = require("../controllers/studenti");

const router = express.Router();


module.exports = router;
