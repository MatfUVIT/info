// 3. zadatak
async function prikaziPocetnuStranicu(req, res, next) {
    
}

// 3. zadatak 
async function prikaziStudenta(req, res, next) {
    
}


// 4. zadatak
async function dodajPolaganje(req, res, next) {
    
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziStudenta,
    dodajPolaganje	
};
