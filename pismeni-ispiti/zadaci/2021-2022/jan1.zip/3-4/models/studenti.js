// 3. zadatak
async function dohvatiStudenta(indeks){
    
}

module.exports = {
    dohvatiStudenta
};
