// 3. zadatak
async function dohvatiSvaPolaganjaZaStudenta(indeks){
    
}


// 4s. zadatak
async function dodajPolaganje(indeks, rok, predmet, espb, ocena) {
    
}

module.exports = {
    dohvatiSvaPolaganjaZaStudenta,
    dodajPolaganje
};
