// 3. zadatak
async function prikaziPocetnuStranicu(req, res, next) {
    
}

// 3. zadatak 
async function prikaziRezultate(req, res, next) {
    
}


// 4. zadatak
async function unesiPitanje(req, res, next) {
    
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziRezultate,
    unesiPitanje	
};
