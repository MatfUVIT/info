const express = require("express");
const kontroler = require("../controllers/rezultat");


const router = express.Router();


module.exports = router;
