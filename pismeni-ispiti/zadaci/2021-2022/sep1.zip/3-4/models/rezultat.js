// 3. zadatak
async function dohvatiRezultate(username, password){

}

module.exports = {
    dohvatiRezultate
};
