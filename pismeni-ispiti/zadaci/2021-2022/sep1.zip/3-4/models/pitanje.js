// 4. zadatak
async function ubaciPitanje(tekst, odgovor, oblast, tezina){

}

module.exports = {
    ubaciPitanje
};
