// 3. zadatak
async function prikaziPocetnuStranicu(req, res, next) {
    res.render('pocetna.ejs');
}

const lekModel = require('../models/lekovi.js');
// 3. zadatak 
async function prikaziLekove(req, res, next) {
    const data = req.query;
    console.log(data);
    let simptomi = [];
    if (data.upalagrla ==='on'){
        simptomi.push('upala grla');
    }
    if (data.cnos==='on'){
        simptomi.push('curenje nosa');
    }
    if (data.temp ==='on'){
        simptomi.push('temperatura');
    }
    if (data.glavobolja ==='on'){
        simptomi.push('glavobolja');
    }
    if (data.pritisak === 'on'){
        simptomi.push('pritisak');
    }
    console.log(simptomi);
    let trazeni_lekovi = await lekModel.dohvatiLekove(simptomi);
    console.log(trazeni_lekovi);
    res.render('lekovi.ejs', {
        lekovi: trazeni_lekovi
    });
}


// 4. zadatak
async function prikaziRecept(req, res, next) {
    
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziLekove,
    prikaziRecept	
};
