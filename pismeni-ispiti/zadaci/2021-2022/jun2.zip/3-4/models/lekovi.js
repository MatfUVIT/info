const mongoose = require('mongoose');

const lekSchema = new mongoose.Schema({
    _id : mongoose.Schema.Types.ObjectId,
    nazivLeka: {
        type:String,
        required: true
    },
    proizvodjac: {
        type:String,
        required: true
    },
    simptomi:{
        type: [String],
        required: true
    },
    miligrami: {
        type:[String],
        required: true
    }
},{collection:"lekovi"});
const LekModel = mongoose.model('Lek', lekSchema);

// 3. zadatak
async function dohvatiLekove(spisak_simptoma){
    let niz_lekova =[];
    
    let svi_lekovi = await LekModel.find({}).exec();
    for (let lek of svi_lekovi){
        let dodajemo=false;
        for (let s of spisak_simptoma){
            if (lek.simptomi.includes(s)){
                    dodajemo = true;
                    break;
            }
        }
        if (dodajemo){
            niz_lekova.push(lek);
        }
    }
    return niz_lekova;
}

module.exports = {
    dohvatiLekove
};
