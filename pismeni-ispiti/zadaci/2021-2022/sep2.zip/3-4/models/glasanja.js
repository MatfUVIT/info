// 3. zadatak
async function dodajNovoGlasanje(izvodjac, promena_procenta, kostim, koreografija, tekst, melodija){
    
}

module.exports = {
    dodajNovoGlasanje
};
