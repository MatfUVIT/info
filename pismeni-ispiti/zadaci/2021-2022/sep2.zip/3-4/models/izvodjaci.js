// 3. zadatak
async function dohvatiSveIzvodjace() {
    
}

//3. zadatak
async function azurirajProseke(izvodjac){

}

// 4. zadatak
async function dohvatiKonkretnogIzvodjaca(izvodjac) {
    
}

module.exports = {
    dohvatiSveIzvodjace,
    azurirajProseke,
    dohvatiKonkretnogIzvodjaca
};
