// 3. zadatak
async function prikaziPocetnuStranicu(req, res, next) {
    
}

// 3. zadatak 
async function unesiRezultateGlasanja(req, res, next) {
    
}


// 4. zadatak
async function prikaziIzvestaj(req, res, next) {
    
}

module.exports = {
    prikaziPocetnuStranicu,
    unesiRezultateGlasanja,
    prikaziIzvestaj	
};
