const express = require("express");
const kontroler = require("../controllers/izvodjaci");

const router = express.Router();


module.exports = router;
