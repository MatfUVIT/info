const express = require('express');

const controller = require('../controllers/reading');
const router = express.Router();



module.exports = router;
