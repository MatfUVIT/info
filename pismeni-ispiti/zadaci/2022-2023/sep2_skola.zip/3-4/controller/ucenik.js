const mongoose = require('mongoose');
const ucenikModel = require('../model/ucenik');


async function prikaziPocetnu(req, res, next) {
    try {
	
    } catch(err){
        next(err);
    }
}


async function prikaziOcene(req, res, next) {
    try {
      
    } catch(err){
        next(err);
    }
}


async function unesiOcenu(req, res, next){
	 try {
      
    } catch(err){
        next(err);
    }
}




module.exports = {
    prikaziPocetnu,
    prikaziOcene,
    unesiOcenu
};
