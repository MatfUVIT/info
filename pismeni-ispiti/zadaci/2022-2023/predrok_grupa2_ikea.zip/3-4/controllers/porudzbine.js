const porudzbineModel = require('../models/porudzbine');

// 3. zadatak
async function prikaziPocetnuStranicu(req, res, next) {
    try {

    } catch (err) {
        next(err);
    }
}

// 3. zadatak 
async function prikaziFormular(req, res, next) {
    try {
     
    } catch (err) {
        next(err);
    }
}

// 3. zadatak
async function prikaziPorudzbine(req, res, next){
    try {
       
    } catch (err) {
        next(err);
    }
}


// 4. zadatak
async function zavrsiIzmene(req, res, next) {
    
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziFormular,
    prikaziPorudzbine,
    zavrsiIzmene
};
