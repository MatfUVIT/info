const mongoose = require('mongoose');


// 3. zadatak
async function dohvatiSvePorudzbineDatum(username, datum_od, datum_do){
}

// 3. zadatak
async function dohvatiSvePorudzbineStatus(username, status){
}

// 4. zadatak
async function izmeniPorudzbine(spisak_porudzbina, cenaSeRacunala) {
    
}

module.exports = {
    dohvatiSvePorudzbineDatum,
    dohvatiSvePorudzbineStatus,
    izmeniPorudzbine
};
