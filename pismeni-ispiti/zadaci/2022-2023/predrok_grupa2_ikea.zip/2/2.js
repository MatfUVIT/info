// mozete napraviti niz slika, ili objekata koji sadrze niz slika uz ostalo sto vam je potrebno
