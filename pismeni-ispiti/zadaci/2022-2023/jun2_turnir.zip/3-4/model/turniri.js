const mongoose = require('mongoose')



async function dohvatiIgreZaTurnir(turnir) {
} 


async function dohvatiTurnire() {
}

async function unesiTurnir(igrac1, igrac2, poeni1, poeni2, vreme, turnir) {
} 

module.exports = {
    dohvatiTurnire,
    dohvatiIgreZaTurnir,
    unesiTurnir
};