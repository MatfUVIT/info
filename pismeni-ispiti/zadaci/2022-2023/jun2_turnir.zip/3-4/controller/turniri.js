const mongoose = require('mongoose');
const turniriModel = require('../model/turniri');


async function prikaziPocetnu(req, res, next) {
    try {

    } catch(err){
        next(err);
    }
}


async function prikaziTurnir(req, res, next) {
    try {
        
    } catch(err){
        next(err);
    }
}


async function unesiMec(req, res, next) {
    try {
       
    } catch(err){
        next(err);
    }
}


module.exports = {
    prikaziPocetnu,
    prikaziTurnir,
    unesiMec
};