const express = require('express');

const router = express.Router();

const userListController = require('../controllers/userList');


module.exports = router;
