const accountModel = require('../models/account');

module.exports.prikaziTabelu = async function (req, res, next) {
    try {        

    } catch (err) {
        next(err);
    }
};

module.exports.dodajNalog = async function (req, res, next) {
  try {        

  } catch (err) {
      next(err);
  }
};

module.exports.prikaziBankomat = async function (req, res, next) {
  try {        
    
  } catch (err) {
      next(err);
  }
};

module.exports.transakcija = async function (req, res, next) {
  try {        
    
  } catch (err) {
      next(err);
  }
};