const mongoose = require('mongoose');



module.exports.getAccounts = async function () {
    
};

module.exports.createAccount = async function (ime, prezime, stanje) {
    
};

module.exports.executeTransaction = async function (_id, kolicina, tip) {
    
};