const express = require('express');

const router = express.Router();

const bankController = require('../controllers/bank');



module.exports = router;
