const mongoose = require('mongoose')


async function dohvatiMeseceIzPlanera() {
} 

async function dohvatiPlanoveZaMesec(mesec) {
}

async function obrisiDogadjaj(id) {
} 

module.exports = {
  dohvatiMeseceIzPlanera,
  dohvatiPlanoveZaMesec,
  obrisiDogadjaj
};
