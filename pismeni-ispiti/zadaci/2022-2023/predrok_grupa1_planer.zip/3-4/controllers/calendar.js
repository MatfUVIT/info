const rasporedModel = require('../models/raspored');


async function prikaziPocetnu(req, res, next) {
    try {
       
        
    } catch(err){
        next(err);
    }
}


async function prikaziMesec(req, res, next) {
    try {
       
    } catch(err){
        next(err);
    }
}


async function obrisiMesec(req, res, next) {
    try {
       
    } catch(err){
        next(err);
    }
}


module.exports = {
    prikaziPocetnu,
    prikaziMesec,
    obrisiMesec
};
