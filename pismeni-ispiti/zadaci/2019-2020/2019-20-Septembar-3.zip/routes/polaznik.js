const express = require('express');

const controller = require('../controllers/polaznik');

const router = express.Router();


module.exports = router;