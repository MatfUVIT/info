async function dohvatiDrzaveZaKojePostojeRezultati() {
    
}

async function dohvatiRezultateZirijaZaDrzavu(drzava) {
    
}

async function dohvatiRezultatePublikeZaDrzavu(drzava) {
    
}

module.exports = {
    dohvatiDrzaveZaKojePostojeRezultati,
    dohvatiRezultateZirijaZaDrzavu,
    dohvatiRezultatePublikeZaDrzavu,
};
