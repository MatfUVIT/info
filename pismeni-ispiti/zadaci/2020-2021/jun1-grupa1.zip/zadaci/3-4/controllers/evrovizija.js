async function dohvatiDrzave(req, res, next) {
    
}

async function prikaziRezultate(req, res, next) {
    
}

module.exports = {
    dohvatiDrzave,
    prikaziRezultate,
};
