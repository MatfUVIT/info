async function dohvatiStatistike() {
    
}

async function dohvatiPodatke(grad, sort) {
    
}

module.exports = {
    dohvatiStatistike,
    dohvatiPodatke,
};
