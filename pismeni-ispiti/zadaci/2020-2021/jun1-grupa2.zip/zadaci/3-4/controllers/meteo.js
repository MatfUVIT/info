async function dohvatiStatistike(req, res, next) {
    
}

async function dohvatiDetalje(req, res, next) {
    
}

module.exports = {
    dohvatiStatistike,
    dohvatiDetalje,
};
