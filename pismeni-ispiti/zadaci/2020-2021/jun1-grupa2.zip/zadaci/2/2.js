const temperature = [
    { grad: "Beograd", temperatura: 21 },
    { grad: "Novi Sad", temperatura: 18 },
    { grad: "Subotica", temperatura: 17 },
    { grad: "Nis", temperatura: 25 },
];
