// 3. zadatak
async function prikaziPocetnuStranicu(req, res, next) {
    
}

// 3. zadatak 
async function prikaziRaspored(req, res, next) {
    
}

// 4. zadatak
async function obrisiCas(req, res, next) {
    
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziRaspored,
    obrisiCas
};
