// 3. zadatak
async function dohvatiCasoveZaGrupu(grupa) {
    
}


// 4. zadatak
async function obrisiCas(id) {
    
}

module.exports = {
    dohvatiCasoveZaGrupu,
    obrisiCas,
};
