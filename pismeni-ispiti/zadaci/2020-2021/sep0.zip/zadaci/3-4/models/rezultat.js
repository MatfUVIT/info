

async function dohvatiRezultateZaDrzavu(drzava) {
    
}

async function dohvatiStatistike(drzava) {
    
}

module.exports = {
    dohvatiRezultateZaDrzavu,
    dohvatiStatistike,
};
