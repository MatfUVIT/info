async function prikaziPocetnuStranicu(req, res, next) {
    
}

async function prikaziRezultate(req, res, next) {
    
}

async function prikaziStatistike(req, res, next) {
    
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziStatistike,
    prikaziRezultate
};
