const rezultati = [
    {
        sport: 'Kosarka',
        zlato: 'SAD',
        srebro: 'Francuska',
        bronza: 'Australija'
      },
      {
        zlato: 'SAD',
        srebro: 'Brazil',
        bronza: 'Srbija'
      },
      {
        sport: 'Vaterpolo',
        zlato: 'Srbija',
        srebro: 'Grcka',
        bronza: 'Madjarska'
      },
      {
        sport: 'Karate',
        zlato: 'Srbija',
        srebro: 'Kina',
        bronza: 'Turska'
      },
      {
        sport: 'Tekvondo -49',
        zlato: 'Tajland',
        srebro: 'Spanija',
        bronza: 'Srbija'
      },
      {
        sport: 'Tekvondo +67',
        zlato: 'Srbija',
        srebro: 'Juzna koreja',
        bronza: 'Velika britanija'
      },
      {
        sport: 'Rvanje',
        zlato: 'Ukrajna',
        srebro: 'Madjarska',
        bronza: 'Srbija'
      },
      {
        sport: 'Streljastvo 10',
        zlato: 'Iran',
        srebro: 'Srbija',
        bronza: 'Kina'
      },
      {
        sport: 'Streljastvo 50',
        zlato: 'Kina',
        srebro: 'Rusija',
        bronza: 'Srbija'
      },
      {
        sport: 'Basket',
        zlato: 'Letonija',
        srebro: 'Rusija',
        bronza: 'Srbija'
      }
];
