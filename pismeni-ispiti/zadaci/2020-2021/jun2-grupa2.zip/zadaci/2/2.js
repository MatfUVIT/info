const ispiti = [
    {
        naziv: 'AISP',
        prijavljen: false
    },
    {
        naziv: 'A3',
        prijavljen: false
    },
    {
        naziv: 'KIAA',
        prijavljen: false
    },
    {
        naziv: 'A2',
        prijavljen: true
    },
    {
        naziv: 'UVIT',
        prijavljen: true
    },
    {
        naziv: 'OM',
        prijavljen: false
    },
    {
        naziv: 'OOP',
        prijavljen: true
    },
    {
        naziv: 'OA',
        prijavljen: false
    },
    {
        naziv: 'OS',
        prijavljen: false
    }
];