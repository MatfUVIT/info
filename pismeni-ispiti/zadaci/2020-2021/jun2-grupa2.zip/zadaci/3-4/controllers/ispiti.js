// Za 3. zadatak
async function prikaziPocetnuStranicu(req, res, next) {

}

// Za 3. zadatak
async function unesiIspit(req, res, next) {

}

// Za 4. zadatak
async function prikaziRasporedZaStudenta(req, res, next) {
    
}


module.exports = {
    prikaziPocetnuStranicu,
    prikaziRasporedZaStudenta,
    unesiIspit
};
