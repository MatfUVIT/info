// Za 3. zadatak
async function dohvatiCeoRaspored() {
    return await Raspored.find({}).sort({smer: -1, godina: 1, termin: 1 }).exec();
}

// Za 3. zadatak
async function unesiNoviIspit(godina, smer, termin, predmet) {
    
}

// Za 4. zadatak
async function dohvatiRasporedStudenta(indeks, smer) {
    
}

module.exports = {
    dohvatiCeoRaspored,
    dohvatiRasporedStudenta,
    unesiNoviIspit
};
