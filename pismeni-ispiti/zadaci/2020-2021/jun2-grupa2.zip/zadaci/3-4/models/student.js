// Za 4. zadatak
async function dohvatiInfoStudenta(indeks) {
    
}

module.exports = {
    dohvatiInfoStudenta
};
