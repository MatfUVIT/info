// Za 3. zadatak
async function dohvatiTekucuStatistikuZaSmer(smer) {
    
}

module.exports = {
    dohvatiTekucuStatistikuZaSmer,
};
