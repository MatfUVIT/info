// Za 3. zadatak
async function dohvatiIstorijuStatistikaZaSmer(smer) {
    
}

// Za 4. zadatak
async function unesiStatistikuZaSmer(smer, brojStudenata, prosek, student, datum, imaKomentar, komentar) {
    
}

module.exports = {
    dohvatiIstorijuStatistikaZaSmer,
    unesiStatistikuZaSmer,
};
