// Za 3. zadatak
async function prikaziPocetnuStranicu(req, res, next) {
    
}

// Za 3. zadatak
async function prikaziStatistike(req, res, next) {
    
}

// Za 4. zadatak
async function unesiStatistiku(req, res, next) {
    
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziStatistike,
    unesiStatistiku,
};
