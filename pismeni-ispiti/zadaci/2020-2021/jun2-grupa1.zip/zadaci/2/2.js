function toString() {
    return `${this.imePrezime} ima prosecnu ocenu ${this.prosek} na smeru ${this.smer}`;
}

const studenti = [
    {
        id: 1,
        imePrezime: "Pera Peric",
        prosek: 10.0,
        smer: "I",
        upisan: true,
        toString,
    },
    {
        id: 2,
        imePrezime: "Laza Lazic",
        prosek: 9.21,
        smer: "M",
        upisan: false,
        toString,
    },
    {
        id: 3,
        imePrezime: "Pera Peric",
        prosek: 8.17,
        smer: "M",
        upisan: true,
        toString,
    },
    {
        id: 4,
        imePrezime: "Pera Peric",
        prosek: 9.5,
        smer: "A",
        upisan: true,
        toString,
    },
    {
        id: 5,
        imePrezime: "Pera Peric",
        prosek: 7.0,
        smer: "I",
        upisan: true,
        toString,
    },
    {
        id: 6,
        imePrezime: "Pera Peric",
        prosek: 8.04,
        smer: "I",
        upisan: false,
        toString,
    },
];
