const dogadjaji = [
    { naziv: "JavaScript conference 2021", datum: new Date(2021, 5, 14), prijavljen: false },
    { naziv: "A state of modern web", datum: new Date(2021, 5, 2), prijavljen: false },
    { naziv: "Node Congress", datum: new Date(2021, 3, 14), prijavljen: true },
    { naziv: "HTML + CSS conference", datum: new Date(2021, 7, 6), prijavljen: false },
    { naziv: "RxJS topics", datum: new Date(2021, 8, 24), prijavljen: false },
    { naziv: "TypeScript talks", datum: new Date(2021, 9, 20), prijavljen: true },
    { naziv: "Angular conference", datum: new Date(2021, 1, 9), prijavljen: false },
];

const svetlozelena = 'rgba(128, 255, 0, 0.5)';
const svetlocrvena = 'rgba(220, 20, 60, 0.5)';

function main() {

}

main();
