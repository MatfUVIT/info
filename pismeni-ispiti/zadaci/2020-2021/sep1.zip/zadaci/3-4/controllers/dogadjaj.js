async function prikaziPocetnu(req, res, next) {
    
}

async function prikaziDogadjaje(req, res, next) {
    
}

async function prikaziAzuriranDogadjaj(req, res, next) {
    
}

module.exports = {
    prikaziPocetnu,
    prikaziDogadjaje,
    prikaziAzuriranDogadjaj,
};
