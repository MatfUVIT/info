

async function dohvatiDogadjaje(godina, mesec, dan) {
    
}

async function azurirajDogadjaj(id, naziv, godina, mesec, dan, trajanje) {
    
}

module.exports = {
    dohvatiDogadjaje,
    azurirajDogadjaj,
};
