const mongoose = require('mongoose');


async function dohvatiSvaPutovanja() {
}

async function dohvatiPutovanjaZaDrzavu(drzava) {
}

async function azurirajCenu(naziv, cena) {
}

module.exports = {
    dohvatiSvaPutovanja,
    dohvatiPutovanjaZaDrzavu,
    azurirajCenu
};