const express = require('express');

const router = express.Router();

const controller = require('../controllers/putovanje');


module.exports = router;