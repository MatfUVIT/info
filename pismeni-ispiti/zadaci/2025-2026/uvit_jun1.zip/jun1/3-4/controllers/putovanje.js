const putovanjeModel = require('../models/putovanje');

async function prikaziPocetnu(req, res, next) {
    try {
    }
    catch (err) {
        next(err);
    }
}

async function prikaziPutovanja(req, res, next) {
    try {
    }
    catch (err) {
        next(err);
    }
}

async function ostvariPopust(req, res, next) {
    try {
    }
    catch (err) {
        next(err);
    }
}

module.exports = {
    prikaziPocetnu,
    prikaziPutovanja,
    ostvariPopust
};