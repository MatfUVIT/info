// NE MENJATI OVAJ NIZ
const utakmice = [
    {
        tim1: "Portugal",
        verovatnoća1: 4,
        tim2: "Kolumbija",
        verovatnoća2: 3,
    },
    {
        tim1: "Kolumbija",
        verovatnoća1: 5,
        tim2: "Kurasao",
        verovatnoća2: 3,
    },
    {
        tim1: "Kurasao",
        verovatnoća1: 2,
        tim2: "Portugal",
        verovatnoća2: 6,
    },
]

// DODATI JAVASCRIPT KOD ISPOD