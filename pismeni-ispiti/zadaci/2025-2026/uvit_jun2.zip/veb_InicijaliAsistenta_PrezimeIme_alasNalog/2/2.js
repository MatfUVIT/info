let tasks = [
  {
    name: 'Trening u teretani',
    done: false
  },
  {
    name: 'Zalivanje cveća',
    done: false
  },
  {
    name: 'Priprema večere',
    done: false
  },
  {
    name: 'Kupovina namirnica',
    done: true
  },
  {
    name: 'Pranje automobila',
    done: false
  },
  {
    name: 'Odlazak kod lekara',
    done: true
  },
  {
    name: 'Plaćanje računa',
    done: false
  }
];

// *** STUDENTSKI KOD: *** //

