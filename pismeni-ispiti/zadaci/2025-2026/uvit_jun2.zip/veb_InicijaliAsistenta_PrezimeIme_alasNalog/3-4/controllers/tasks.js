const tasksModel = require('../models/tasks');

async function getAllTasks(req, res, next) {
    try {

    } catch (err) {
        next(err);
    }
}

async function showDetails(req, res, next) {
    try{

    }catch(err){
        next(err);
    }
}

async function markAsDone(req, res, next) {
    try{
        
    }catch(err){
        next(err);
    }
}


async function addNewTask(req, res, next) {
    try{
        
    }catch(err){
        next(err);
    }
}



module.exports = {
    getAllTasks,
    showDetails,
    markAsDone,
    addNewTask
};
