const mongoose = require('mongoose');

async function getAllTasks() {

}

async function getDetailsByTitle(title) {

}

async function deleteTaskByTitle(title) {

}

async function addNewTask(title, description, deadline, important) {
    
}


module.exports = {
    getAllTasks,
    getDetailsByTitle,
    deleteTaskByTitle,
    addNewTask
};
