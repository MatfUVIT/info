const express = require('express');

const kontroler = require('../controllers/pocetna');
const router = express.Router();


module.exports = router;