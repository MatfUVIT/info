const mongoose = require('mongoose')


async function dohvatiOceneUcenika(imePrezime) {
} 

async function dodajNovuOcenu(imePrezime, predmet, ocena){
}



module.exports = {
    dohvatiOceneUcenika,
    dodajNovuOcenu
};
