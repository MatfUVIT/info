let niz = {0:"1.jpeg", 1:"2.webp",2:"1.jpeg", 3:"5.webp", 4:"7.webp", 5:"3.jpeg", 6:"2.webp", 7:"4.jpg", 8:"6.jpeg", 9:"5.webp",10:"8.jpg",
11:"4.jpg",12:"6.jpeg",13:"3.jpeg",
14:"8.jpg", 15:"7.webp"};

