const mongoose = require('mongoose')




async function dohvatiUkupneGlasove() {
	
} 


async function dohvatiGlasoveDrzave(drzava){

}

async function dodajNoviGlas(odDrzave, drzavi, poeni){

}



module.exports = {
    dohvatiUkupneGlasove,
    dohvatiGlasoveDrzave,
    dodajNoviGlas
};
