const mongoose = require('mongoose')

async function dohvatiFilmove() {
} 

async function dodajFilm(naslov, godina, duzina, imdb, zanr) {
}

async function dodajGlumca(id, noviGlumac){
}

async function dohvatiFilm(id) {
} 

module.exports = {
    dohvatiFilmove, 
    dodajFilm,
    dohvatiFilm,
    dodajGlumca
};
