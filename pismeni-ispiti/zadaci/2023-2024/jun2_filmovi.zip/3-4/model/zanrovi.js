const zanrovi = [
    'action',    
    'adventure',
    'animation', 
    'biography',
    'comedy',    
    'crime',
    'drama',     
    'fantasy',
    'kids', 
    'romance',   
    'sci-fi',
    'superhero',
    'tragedy',
    'triler'
]

