const knjigeModel = require('../model/knjige');


async function prikaziPocetnu(req, res, next) {
    try {
    } catch(err){
        next(err);
    }
}


async function dohvatiKnjigu(req, res, next) {
    try {
    } catch(err){
        next(err);
    }
}


async function unesiKnjigu(req, res, next) {
    try {
    } catch(err){
        next(err);
    }
}


module.exports = {
    prikaziPocetnu,
    dohvatiKnjigu,
    unesiKnjigu
};