const mongoose = require('mongoose')

async function dohvatiKnjige() {
} 


async function unesiKnjigu(naslov, pisac, godina, strane) {
}

async function dohvatiKnjigu(id) {
} 

module.exports = {
    dohvatiKnjige, 
    unesiKnjigu,
    dohvatiKnjigu
};