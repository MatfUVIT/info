let niz = ["matf", "uvit", "dugme", "tastatura", "mis"];




