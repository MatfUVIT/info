const mongoose = require('mongoose')


async function dohvatiInfo(city) {
} 

async function dohvatiPitanja(city){
}



module.exports = {
    dohvatiInfo,
    dohvatiPitanja
};


