const mongoose = require('mongoose')

async function dohvatiLet(from, to, date) {
} 

module.exports = {
    dohvatiLet
};


