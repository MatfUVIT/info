const mongoose = require('mongoose');
const letoviModel = require('../model/letovi');
const gradoviModel = require('../model/gradovi');

async function prikaziPocetnu(req, res, next) {
    try {
    } catch(err){
        next(err);
    }
}


async function prikaziLetove(req, res, next) {
    try {
    } catch(err){
        next(err);
    }
}


async function prikaziKranjuDestinaciju(req, res, next){
	 try {
    } catch(err){
        next(err);
    }
}




module.exports = {
    prikaziPocetnu,
    prikaziKranjuDestinaciju,
    prikaziLetove
};
