const recipes = [
    {
        name: 'Pizza Margherita', 
        image: 'pizza.jpg'
    },
    {
        name: 'Spaghetti alla Carbonara', 
        image: 'carbonara.jpg'
    },
    {
        name: 'Lasagne', 
        image: 'lasagne.jpg'
    },
    {
        name: 'Fettuccine Alfredo', 
        image: 'fettuccine.jpg'
    },
    {
        name: 'Spaghetti Bolognese', 
        image: 'bolognese.jpg'
    },
    {
        name: 'Spinach & Ricotta Cannelloni', 
        image: 'cannelloni.jpg'
    }
];

