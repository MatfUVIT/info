const mongoose = require('mongoose');

async function getAllRecipes(){

}

async function searchRecipes(search){

}

async function addNewRecipe(recipe){

}

module.exports = {
    getAllRecipes,
    searchRecipes,
    addNewRecipe
};
