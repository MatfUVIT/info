const express = require("express");
const controller = require("../controllers/recipes");

const router = express.Router();


module.exports = router;
