const recipesModel = require('../models/recipes');
async function showAllRecipes(req, res, next) {
    try{

    }catch(err){
        next(err);
    }
}

async function searchRecipes(req, res, next) {
    try{
 
    }catch(err){
        next(err);
    }
}

async function addNewRecipe(req, res, next) {
    try{

    }catch(err){
        next(err);
    }
}

module.exports = {
    showAllRecipes,
    searchRecipes,
    addNewRecipe	
};
