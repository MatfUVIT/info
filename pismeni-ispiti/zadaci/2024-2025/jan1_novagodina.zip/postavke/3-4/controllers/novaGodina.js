const modelDela = require('../models/dela');

async function prikaziPocetnuStranicu(req, res, next) {
    try {
    } catch (err) {
        next(err);
    }
}

async function prikaziDete(req, res, next) {
    try {
    } catch (err) {
        next(err);
    }
}

async function unesiDelo(req, res, next){
    try {
    } catch (err) {
        next(err);
    }
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziDete,
    unesiDelo
};