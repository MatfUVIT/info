const mongoose = require('mongoose');

async function dohvatiDela(){
}

async function dohvatiDelaPoImenu(ime){
}

async function sacuvajDelo(dete, delo, poeni) {
}

module.exports = {
    dohvatiDela,
    dohvatiDelaPoImenu,
    sacuvajDelo
};