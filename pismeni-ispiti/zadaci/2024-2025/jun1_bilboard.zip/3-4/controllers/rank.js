const model = require('../models/rank');

async function prikaziPocetnuStranicu(req, res, next) {
    try {
    } catch (err) {
        next(err);
    }
}



async function prikaziNedeljniIzvestaj(req, res, next) {
    try {
    } catch (err) {
        next(err);
    }
}

async function izmeniRank(req, res, next){
    try {
    } catch (err) {
        next(err);
    }
}

module.exports = {
    prikaziPocetnuStranicu,
    prikaziNedeljniIzvestaj,
    izmeniRank
};