const mongoose = require('mongoose');


async function dohvatiDatume(){
}

async function dohvatiIzvestaj(date) {
}

async function promeniRang(datum, rank, inc, id) {
}

module.exports = {
    dohvatiDatume,
    dohvatiIzvestaj,
    promeniRang
};