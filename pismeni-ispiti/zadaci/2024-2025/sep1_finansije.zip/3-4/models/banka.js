const mongoose = require("mongoose");


async function nadjiIliKreirajKorisnika(firstName, lastName, email, password) {
}

async function dohvatiAktivneSortirano() {
}

async function azurirajTransakciju(email, amount, type) {
}

module.exports = {
    nadjiIliKreirajKorisnika,
    azurirajTransakciju,
    dohvatiAktivneSortirano
};
