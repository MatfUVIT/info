const userModel = require("../models/banka");

async function showLogin(req, res, next) {
    try {

    } catch (err) {
        next(err);
    }
}

async function loginUser(req, res, next) {
    try {

    } catch (err) {
        next(err);
    }
}


async function azurirajTabelu(req, res, next) {
    try {

    } catch (err) {
        next(err);
    }
}

module.exports = { showLogin, loginUser, azurirajTabelu };
