const slike = [
    ["img/1.jpg", "Ponuda kredita"],
    ["img/2.jpg", "Članska kartica"],
    ["img/3.jpg", "Program štednje"],
    ["img/4.jpg", "Garancija sigurnosti"]
];

