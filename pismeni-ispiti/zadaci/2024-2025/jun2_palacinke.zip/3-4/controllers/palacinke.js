const priloziModel = require('../models/prilozi');

async function prikaziPocetnu(req, res, next) {
    try {
    } catch (err) {
        next(err);
    }
}

async function filterPriloga(req, res, next) {
    try {
    } catch (err) {
        next(err);
    }
}

async function dostava(req, res, next) {
    try {
    } catch (err) {
        next(err);
    }
}


module.exports = {
    prikaziPocetnu,
    filterPriloga,
    dostava
};
