const mongoose = require('mongoose');

async function prikaziPriloge() {
}

async function filterSlatko(slatko) {
}

async function filterVegan() {
}


async function azurirajPopularnost(nazivPriloga) {
}


module.exports = {
    prikaziPriloge,
    filterSlatko,
    filterVegan,
    azurirajPopularnost

};
