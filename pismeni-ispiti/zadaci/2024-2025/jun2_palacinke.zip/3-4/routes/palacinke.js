const express = require("express");
const controller = require("../controllers/palacinke");

const router = express.Router();

module.exports = router;
