slike = {
    "nutela" : "nutela.jpg",
    "plazma" : "plazma.png",
    "dzem" : "dzem.jpg",
    "banana" : "banana.jpg",
    "visnja" : "visnja.jpg",
    "eurokrem" : "eurokrem.jpg"
}
