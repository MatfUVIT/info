const express = require("express");
const controller = require("../controllers/pozoriste");

const router = express.Router();

module.exports = router;
