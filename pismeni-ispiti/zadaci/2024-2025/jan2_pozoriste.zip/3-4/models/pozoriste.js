const mongoose = require('mongoose');



async function prikaziRepertoar() {
}

async function prikaziPredstavu(id) {
}


async function kupiUlaznice(id, lokacija, broj) {
}

module.exports = {
    prikaziRepertoar,
    prikaziPredstavu,
    kupiUlaznice

};
