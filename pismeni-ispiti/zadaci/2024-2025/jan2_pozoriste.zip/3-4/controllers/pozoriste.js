const pozoristeModel = require('../models/pozoriste');

async function prikaziRepertoar(req, res, next){
    try{
        
    }catch (err){
        next(err);
    }
}

async function prikaziPredstavu(req, res, next){
    try{ 

    }catch (err){
        next(err);
    }
}

async function kupiUlaznice(req, res, next){
    try{

    }catch (err){
        next(err);
    }
}

module.exports = {
    prikaziRepertoar,
    prikaziPredstavu,
    kupiUlaznice
};
